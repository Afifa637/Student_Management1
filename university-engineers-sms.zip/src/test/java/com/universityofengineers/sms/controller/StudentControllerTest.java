package com.universityofengineers.sms.controller;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
class StudentControllerTest {

    @Test
    void create() {
    }

    @Test
    void list() {
    }

    @Test
    void get() {
    }

    @Test
    void update() {
    }

    @Test
    void updateStatus() {
    }

    @Test
    void disable() {
    }

    @Test
    void resetPassword() {
    }

    @Test
    void me() {
    }

    @Test
    void updateMe() {
    }
}