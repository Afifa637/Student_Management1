package com.universityofengineers.sms.entity;

public enum TeacherTitle {
    LECTURER,
    SENIOR_LECTURER,
    ASSISTANT_PROFESSOR,
    ASSOCIATE_PROFESSOR,
    PROFESSOR
}
