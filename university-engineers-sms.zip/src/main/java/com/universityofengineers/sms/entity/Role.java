package com.universityofengineers.sms.entity;

public enum Role {
    STUDENT,
    TEACHER
}
