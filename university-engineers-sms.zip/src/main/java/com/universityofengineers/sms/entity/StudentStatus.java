package com.universityofengineers.sms.entity;

public enum StudentStatus {
    ACTIVE,
    SUSPENDED,
    GRADUATED,
    DROPPED
}
