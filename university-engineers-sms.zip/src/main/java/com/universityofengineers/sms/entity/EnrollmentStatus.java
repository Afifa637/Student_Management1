package com.universityofengineers.sms.entity;

public enum EnrollmentStatus {
    ENROLLED,
    DROPPED,
    COMPLETED
}
